package com.xworkz.ArrayCRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArrayCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
